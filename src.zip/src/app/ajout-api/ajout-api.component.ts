import { Component } from '@angular/core';

@Component({
  selector: 'app-ajout-api',
  templateUrl: './ajout-api.component.html',
  styleUrls: ['./ajout-api.component.css']
})
export class AjoutApiComponent {

}
