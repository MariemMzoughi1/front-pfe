import { Component } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-gestion-systeme',
  templateUrl: './gestion-systeme.component.html',
  styleUrls: ['./gestion-systeme.component.css']
})
export class GestionSystemeComponent {

  constructor(private route:Router){}

  ajoutsysteme(){
    this.route.navigate(['/ajout-systeme']);
  }

}
