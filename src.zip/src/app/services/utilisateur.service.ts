import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Utilisateur } from '../models/utilisateur.request';

const API_URL = 'http://localhost:8080/utilisateurs/';


@Injectable({
  providedIn: 'root'
})
export class UtilisateursService {

  constructor(private http:HttpClient) { }

  getAll() {
    return this.http.get<Utilisateur[]>(API_URL);
  }

  get(Matricule: string)  {
    return this.http.get<Utilisateur>(API_URL+Matricule);
  }

  create(data: any): Observable<any> {
    return this.http.post(API_URL, data);
  }

  update(Matricule: string, data: any) {
    return this.http.put(API_URL+Matricule, data);
  }

  delete(Matricule: string): Observable<any> {
    return this.http.delete(API_URL+Matricule);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(API_URL);
  }

}
