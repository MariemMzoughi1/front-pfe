import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TokenStorageService } from '../services/token-storage.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit{
  
  constructor(private tokenStorageService: TokenStorageService , private router:Router) {
    
  }
ngOnInit(): void {
  
}
onLogout(): void {
  this.tokenStorageService.signOut();
  this.router.navigateByUrl('/login');

}
}
