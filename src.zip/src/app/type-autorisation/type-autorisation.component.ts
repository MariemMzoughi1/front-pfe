import { Component } from '@angular/core';

@Component({
  selector: 'app-type-autorisation',
  templateUrl: './type-autorisation.component.html',
  styleUrls: ['./type-autorisation.component.css']
})
export class TypeAutorisationComponent {

}
