export interface Application{
      code_souscription :string
	  code_API :string
	  code_application :string
	  code_type_autorisation :string
	  code_autorisation :string
	  date_création :number
	  date_expiration :number
	  clé :string
      active :number
}