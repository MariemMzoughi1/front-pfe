export interface Application{
    code_application :string
    libellé_application :string
    propriétaire :string
    admin :string
    code_type_app :string
}