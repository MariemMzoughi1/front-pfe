export interface Systeme{
code_systeme :string
libellé_systeme :string
}