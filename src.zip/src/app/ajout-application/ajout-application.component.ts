import { Component } from '@angular/core';

@Component({
  selector: 'app-ajout-application',
  templateUrl: './ajout-application.component.html',
  styleUrls: ['./ajout-application.component.css']
})
export class AjoutApplicationComponent {

}
