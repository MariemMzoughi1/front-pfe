import { Component } from '@angular/core';

@Component({
  selector: 'app-gestion-souscription',
  templateUrl: './gestion-souscription.component.html',
  styleUrls: ['./gestion-souscription.component.css']
})
export class GestionSouscriptionComponent {

}
