import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gestion-api',
  templateUrl: './gestion-api.component.html',
  styleUrls: ['./gestion-api.component.css']
})
export class GestionApiComponent {

  constructor(private route:Router){}

  ajoutapi(){
    this.route.navigate(['/ajout-api']);
  }

}
