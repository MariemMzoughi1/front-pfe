import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-ajout-utilisateur',
  templateUrl: './ajout-utilisateur.component.html',
  styleUrls: ['./ajout-utilisateur.component.css']
})
export class AjoutUtilisateurComponent implements OnInit{


  constructor(private toastr: ToastrService) {


  }

  ngOnInit(): void {
    this.toastr.success('Bienvenu :D');
  }

}
