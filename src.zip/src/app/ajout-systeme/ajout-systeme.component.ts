import { Component } from '@angular/core';

@Component({
  selector: 'app-ajout-systeme',
  templateUrl: './ajout-systeme.component.html',
  styleUrls: ['./ajout-systeme.component.css']
})
export class AjoutSystemeComponent {

}
