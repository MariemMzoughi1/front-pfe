import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gestion-utilisateur',
  templateUrl: './gestion-utilisateur.component.html',
  styleUrls: ['./gestion-utilisateur.component.css']
})
export class GestionUtilisateurComponent implements OnInit{

   constructor(private router:Router) {

   }

  ngOnInit(): void {
  }

  goToAddUser(){
    this.router.navigateByUrl('ajout-utilisateur')
  }
}
