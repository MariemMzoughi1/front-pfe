import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gestion-application',
  templateUrl: './gestion-application.component.html',
  styleUrls: ['./gestion-application.component.css']
})
export class GestionApplicationComponent {

  constructor(private route:Router){}

  ajoutapplication(){
    this.route.navigate(['/ajout-application']);
  }

}
