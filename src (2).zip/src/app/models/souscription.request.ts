export interface Souscription{
      code_souscription :number
	  code_API :string
	  code_application :string
	  code_type_autorisation :string
	  code_autorisation :string
	  date_creation :Date
	  date_expiration :Date
	  cle :string
      active :number
}