export interface Systeme{
    codesysteme :string
    libsysteme:string
    nature :string
}