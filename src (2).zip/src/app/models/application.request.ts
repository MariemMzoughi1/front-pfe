export interface Application{
    code_application :string
    libelle_application :string
    proprietaire :string
    admin :string
    code_type_app :string
}