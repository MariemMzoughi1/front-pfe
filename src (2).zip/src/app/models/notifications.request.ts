export interface Notifications{
    sender :string
    subject :string
    body :string

}