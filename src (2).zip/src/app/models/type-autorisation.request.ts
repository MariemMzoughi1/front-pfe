export interface TypeAutorisation{
    codetypeautorisation :string
    libtypeautorisation :string
    }